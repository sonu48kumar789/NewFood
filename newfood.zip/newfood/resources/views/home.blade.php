@extends('base')


@section('content')
    
    

<div class="jumbotron bg-transparent rounded-0" style="background-image:url('wp1929358.jpg');height:150px;background-size:cover">
    <div class="col-lg-6 mx-auto">
        <h2 class="text-white text-center">Msaledar  Food Item</h2>
    </div>
</div>

<div class="container-fluid">
<div class="row">
    <div class="col-lg-2">
        <div class="list-group border-0 shadow-sm">
            <a herf="" class="list-group-item list-group-item-action bg-danger text-white">Food Item</a>
            <a herf="" class="list-group-item list-group-item-action">Somassa</a>
            <a herf="" class="list-group-item list-group-item-action">Somassa</a>
            <a herf="" class="list-group-item list-group-item-action">Somassa</a>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="row">
            <div class="col-lg-4">
                <div class="card">  
                <span class="veg bg-success">Veg</span>
                    <img src="sk.jpg" alt="" class="" style="width: 192px; height:120px;">
                    <div class="card-body">
                        <h2 class="small font-weight-bolder">Burger</h2>
                        <div class="row no-gutters">
                            <div class="col">
                                <h2 class="h6 mt-1"> ₹4545/-</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="card">  
                <span class="veg bg-danger">Non-Veg</span>
                    <img src="sk1.jpg" alt="" style="width: 192px; height:120px;">
                    <div class="card-body">
                        <h2 class="small font-weight-bolder">Burger</h2>
                        <div class="row no-gutters">
                            <div class="col">
                                <h2 class="h6 mt-1"> ₹4545/-</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="card">  
                <span class="veg bg-success">Veg</span>
                    <img src="wp1929358.jpg" alt="" style="width: 192px; height:120px;">
                    <div class="card-body">
                        <h2 class="small font-weight-bolder">Burger</h2>
                        <div class="row no-gutters">
                            <div class="col">
                                <h2 class="h6 mt-1"> ₹4545/-</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 mt-1">
                <div class="card">  
                <span class="veg bg-success">Veg</span>
                    <img src="sk.jpg" alt="" class="" style="width: 192px; height:120px;">
                    <div class="card-body">
                        <h2 class="small font-weight-bolder">Burger</h2>
                        <div class="row no-gutters">
                            <div class="col">
                                <h2 class="h6 mt-1"> ₹4545/-</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 mt-1">
                <div class="card">  
                <span class="veg bg-danger">Non-Veg</span>
                    <img src="sk1.jpg" alt="" style="width: 192px; height:120px;">
                    <div class="card-body">
                        <h2 class="small font-weight-bolder">Burger</h2>
                        <div class="row no-gutters">
                            <div class="col">
                                <h2 class="h6 mt-1"> ₹4545/-</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 mt-1">
                <div class="card">  
                <span class="veg bg-success">Veg</span>
                    <img src="wp1929358.jpg" alt="" style="width: 192px; height:120px;">
                    <div class="card-body">
                        <h2 class="small font-weight-bolder">Burger</h2>
                        <div class="row no-gutters">
                            <div class="col">
                                <h2 class="h6 mt-1"> ₹4545/-</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 mt-1">
                <div class="card">  
                <span class="veg bg-success">Veg</span>
                    <img src="wp1929358.jpg" alt="" style="width: 192px; height:120px;">
                    <div class="card-body">
                        <h2 class="small font-weight-bolder">Burger</h2>
                        <div class="row no-gutters">
                            <div class="col">
                                <h2 class="h6 mt-1"> ₹4545/-</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            
        </div>
    </div>
    <div class="col-lg-4">
            <div class="col-lg-12">
                <div class="row">
                    <div class="col-lg-3 mt-1">
                        <h5>Burger</h5>
                        </div>
                        <div class="col-lg-4">
                           <a href="" class="btn btn-danger">-</a>
                            <span>2</span>
                            <a href="" class="btn btn-success">+</a>
                        </div>
                        <div class="col-lg-5">
                            <div class="row">
                                <div class="col-lg-6">
                                    <h5 class="ml-2">Total:</h5>
                                </div>
                                <div class="col-lg-6">
                                    <h6>₹445/-</h6>
                                    <h6 class="small text-muted">145/- Per Unit</h6>
                                </div>
                            </div> 
                        </div>
                    </div>
            </div>

            <div class="col-lg-12">
                <div class="row">
                    <div class="col-lg-3 mt-1">
                        <h5>Burger</h5>
                        </div>
                        <div class="col-lg-4">
                           <a href="" class="btn btn-danger">-</a>
                            <span>2</span>
                            <a href="" class="btn btn-success">+</a>
                        </div>
                        <div class="col-lg-5">
                            <div class="row">
                                <div class="col-lg-6">
                                    <h5 class="ml-2">Total:</h5>
                                </div>
                                <div class="col-lg-6">
                                    <h6>₹445/-</h6>
                                    <h6 class="small text-muted">145/- Per Unit</h6>
                                </div>
                            </div> 
                        </div>
                    </div>
            </div>

            <div class="col-lg-12">
                <div class="row">
                    <div class="col-lg-3 mt-1">
                        <h5>Burger</h5>
                        </div>
                        <div class="col-lg-4">
                           <a href="" class="btn btn-danger">-</a>
                            <span>2</span>
                            <a href="" class="btn btn-success">+</a>
                        </div>
                        <div class="col-lg-5">
                            <div class="row">
                                <div class="col-lg-6">
                                    <h5 class="ml-2">Total:</h5>
                                </div>
                                <div class="col-lg-6">
                                    <h6>₹445/-</h6>
                                    <h6 class="small text-muted">145/- Per Unit</h6>
                                </div>
                            </div> 
                        </div>
                    </div>
            </div>

                

               
                    <div class="row">
                        <div class="col-lg-6">
                            <br>
                            <h4 class="ml-2">Total:</h4>
                        </div>
                        <div class="col-lg-6">
                            <br>
                            <h3>₹445/-</h3>
                            <h6 class="small text-danger">10% Discount</h6>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-6">
                            <a href="" class="btn btn-success btn-block">Print</a>
                        </div>
                        <div class="col-lg-6">
                            <a href="" class="btn btn-warning btn-block text-white">Cheeckout</a>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>
  </div>
</div>
@endsection
