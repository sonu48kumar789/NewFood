<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Category;
use App\Models\Foodss;
use Illuminate\Support\Facades\Auth;
class Home extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index(Request $request)
    {
        return view('home');
    }
    public function insertca(Request $request){
       
        return view('inesertcat');
    }
    public function insertfo(Request $request){
        
        return view("insertfood");
    }
    public function insertcat(Request $req)
    {
        $req->validate([
            'c_name'=>'required',
            'c_status'=>'required',
        ]);
        $post = new Category();
        $post->c_name = $req->c_name;
        $post->c_status = $req->c_status;
        $post->save();

        return redirect()->back();
    }
    public function insertfood(Request $req)
    {
        $req->validate([
            'title'=>'required',
            'img'=>'required',
            'price'=>'required',
        ]);
        $post = new Foodss();
        $post->title = $req->title;
        $post->img = $req->img;
        $post->price = $req->price;
        $post->user_id = $req->Auth::loginUsingId();
        $post->category_id = $req->category::Id();
        $post->save();
        
        return redirect()->back();
    }
}
