


<?php $__env->startSection('content'); ?>
    
    

<div class="jumbotron bg-transparent rounded-0" style="background-image:url('wp1929358.jpg');height:150px;background-size:cover">
    <div class="col-lg-6 mx-auto">
        <h2 class="text-white text-center">Msaledar  Food Item</h2>
    </div>
</div>

<div class="container-fluid">
    <div class="row">
        <div class="col-lg-6 mx-auto">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <form action="<?php echo e(route('insertfood')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="">Title</label>
                            <input type="text" name="title" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="">Image</label>
                            <input type="file" name="img" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="">Price</label>
                            <input type="text" name="price class="form-control">
                        </div>
                        <div class="form-group form-check">
                            <input type="checkbox" class="form-check-input" id="exampleCheck1">
                            <label class="form-check-label" for="exampleCheck1">Check me out</label>
                          </div>
                        <div class="form-group">
                            <input type="submit" name="send" class="btn btn-danger">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SonuKumar\Desktop\newfood\resources\views/insertfood.blade.php ENDPATH**/ ?>