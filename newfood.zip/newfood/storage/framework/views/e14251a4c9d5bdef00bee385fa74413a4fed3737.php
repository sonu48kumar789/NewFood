<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    <!-- CSS only -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-danger">
    <a class="navbar-brand" href="<?php echo e(route('homepage' )); ?>">Sonu Foods</a>

    <ul class="navbar-nav ml-auto">
        <li class="nav-item"><a href="<?php echo e(route('insertc' )); ?>" class="nav-link text-white">insert category</a></li>
        <li class="nav-item"><a href="<?php echo e(route('insertf' )); ?>" class="nav-link text-white">insert Food</a></li>
    
    
    </ul>
</nav>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->yieldSection(); ?>

</body>
</html><?php /**PATH C:\Users\SonuKumar\Desktop\newfood\resources\views/base.blade.php ENDPATH**/ ?>